import requests
import json
import time

cung_list = ["Mệnh", "Phụ Mẫu", "Phúc Đức", "Điền Trạch", "Sự Nghiệp", "Giao Hữu", "Thiên Di", "Tật Ách", "Tài Bạch", "Tử Nữ", "Phu - Thê", "Huynh Đệ"]
tu_hoa_list = ["hoá Lộc", "hoá Quyền", "hoá Khoa", "hoá Kị"]
base_url = "https://minhphucduong.vn/ketquatratuong"
all_data = []

print("🚀 Đang quét dữ liệu 672 tượng... Vui lòng đợi.")

for c1 in cung_list:
    for ph in tu_hoa_list:
        for c2 in cung_list:
            params = {'cung1': c1, 'phihoa': ph, 'cung2': c2}
            try:
                response = requests.get(base_url, params=params)
                if response.status_code == 200:
                    all_data.append(response.json())
                time.sleep(0.2) # Tăng tốc độ quét một chút
            except:
                pass

# Lưu dưới dạng biến JavaScript để tránh lỗi CORS
with open('database.js', 'w', encoding='utf-8') as f:
    f.write("const tuViData = ")
    json.dump(all_data, f, ensure_ascii=False, indent=4)
    f.write(";")

print("✅ Đã tạo xong file database.js!")