DB_KEY = "user_list";

function autodata() {
	var doc = document;
	doc.getElementById('ID_NGAYDL').selectedIndex = 0;
	doc.getElementById("ID_NAMDL").selectedIndex = 0;
	doc.getElementById("ID_GIODL").selectedIndex = 0;
	doc.getElementById("ID_GIOITINH").selectedIndex = 0;
	doc.getElementById("ID_THANGDL").selectedIndex = 0;


	doc.getElementById('ID_TEN').value = "Undef";
	doc.getElementById('ID_GIOITINH').value = 1;
	doc.getElementById('ID_NGAYDL').value = 28;
	doc.getElementById('ID_THANGDL').value = 7;
	doc.getElementById("ID_NAMDL").value = 1991;
	doc.getElementById('ID_GIODL').value = 7;
	doc.getElementById('ID_PHUTDL').value = 5;
	doc.getElementById('ID_SAO3').value = "TCP1";
}

function saveFormData() {
	const name = document.getElementById('ID_TEN').value;
	const birth_year = document.getElementById('ID_NAMDL').value;
	const birth_month = document.getElementById('ID_THANGDL').value;
	const birth_date = document.getElementById('ID_NGAYDL').value;
	const birth_time = document.getElementById('ID_GIODL').value;
	const birth_minute = document.getElementById('ID_PHUTDL').value;
	const gender = document.getElementById('ID_GIOITINH').value;

	const data = {
		name: name,
		birth_year: birth_year,
		birth_month: birth_month,
		birth_date: birth_date,
		birth_time: birth_time,
		birth_minute: birth_minute,
		gender: gender,
	};

	let savedData = JSON.parse(localStorage.getItem(DB_KEY)) || [];
	const isDuplicate = savedData.some(item => 
		item.name === data.name &&
		item.birth_year === data.birth_year &&
		item.birth_month === data.birth_month &&
		item.birth_date === data.birth_date &&
		item.birth_time === data.birth_time &&
		item.birth_minute === data.birth_minute &&
		item.gender === data.gender
	);

	if (!isDuplicate) {
		savedData.push(data);
		localStorage.setItem(DB_KEY, JSON.stringify(savedData));
		loadSavedData();
	}
}

function removeUserInfo() {
	let savedData = JSON.parse(localStorage.getItem(DB_KEY)) || [];
	const savedInfoList = document.getElementById('USER_LIST');
	const selectedIndex = savedInfoList.selectedIndex;

	if (selectedIndex !== -1) {
		savedData.splice(selectedIndex, 1);
		console.log(savedData);
		console.log(selectedIndex);
		localStorage.setItem(DB_KEY, JSON.stringify(savedData));
		loadSavedData();
		setup();
	}
}

function loadUserInfo(index) {
	const savedData = JSON.parse(localStorage.getItem(DB_KEY)) || [];
	const selectedItem = savedData[index];
	document.getElementById('ID_TEN').value = selectedItem.name;
	document.getElementById('ID_NAMDL').value = selectedItem.birth_year;
	document.getElementById('ID_THANGDL').value = selectedItem.birth_month;
	document.getElementById('ID_NGAYDL').value = selectedItem.birth_date;
	document.getElementById('ID_GIODL').value = selectedItem.birth_time;
	document.getElementById('ID_PHUTDL').value = selectedItem.birth_minute;
	document.getElementById('ID_GIOITINH').value = selectedItem.gender;
	setup();
}

function loadSavedData() {
	const savedData = JSON.parse(localStorage.getItem(DB_KEY)) || [];
	const savedInfoList = document.getElementById('USER_LIST');
	savedInfoList.innerHTML = '';

	savedData.forEach((item, index) => {
		const li = document.createElement('option');
		li.textContent = `${item.name} - ${item.birth_date}/${item.birth_month}/${item.birth_year} - ${item.birth_time}:${item.birth_minute} - ${item.gender == 1 ? 'Nam' : 'Nữ'}`;
		li.dataset.index = index;

		// const deleteBtn = document.createElement('button');
		// deleteBtn.textContent = 'Xóa';
		// deleteBtn.classList.add('delete-btn');
		// deleteBtn.addEventListener('click', function(e) {
		// 	e.stopPropagation();
		// 	deleteFormData(index);
		// });

		// li.appendChild(deleteBtn);

		// li.addEventListener('click', function() {
		// 	const selectedItem = savedData[this.dataset.index];
		// 	document.getElementById('name').value = selectedItem.name;
		// 	document.getElementById('birth_date').value = selectedItem.birth_date;
		// 	document.getElementById('birth_time').value = selectedItem.birth_time;
		// 	document.getElementById('birth_minute').value = selectedItem.birth_minute;
		// 	document.getElementById('timezone').value = selectedItem.timezone;
		// 	document.getElementById('gender').value = selectedItem.gender;
		// 	document.getElementById('cung').value = selectedItem.cung;
		// 	document.getElementById('year').value = selectedItem.year;
		// 	document.getElementById('render-btn').click();
		// });
		savedInfoList.appendChild(li);
	});
}

function deleteFormData(index) {
	let savedData = JSON.parse(localStorage.getItem(DB_KEY)) || [];
	savedData.splice(index, 1);
	localStorage.setItem(DB_KEY, JSON.stringify(savedData));
	loadSavedData();
}

autodata();
loadSavedData();